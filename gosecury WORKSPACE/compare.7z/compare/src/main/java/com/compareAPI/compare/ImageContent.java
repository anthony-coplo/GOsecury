package com.compareAPI.compare;


public class ImageContent {
 private String imgContent;
 
 public String getImgContent() {
	 return this.imgContent;
 }
 
}
